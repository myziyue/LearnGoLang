# example
wechat sdk examples

## 文档
[wechat sdk文档](https://silenceper.com/wechat)

## Build 
```go
  go build -o bin/example cmd/example/main.go
```
## Run
请修改config.yaml中的相关为自己的参数再运行
```go
./bin/example
```

## 关注公众号

![学点程序](https://silenceper.oss-cn-beijing.aliyuncs.com/qrcode/search_study_program.png)